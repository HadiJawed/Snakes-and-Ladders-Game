import random

# Constants for the board dimensions and the number of players
BOARD_SIZE = 100
NUM_PLAYERS = 2

# Constants for the different squares on the board
START_SQUARE = 0
LADDER_SQUARE = 1
SNAKE_SQUARE = 2
END_SQUARE = 3

# List of squares on the board
board = []

# Initialize the board with all normal squares
for i in range(BOARD_SIZE):
  board.append(START_SQUARE)

# Place ladders and snakes on the board
for i in range(NUM_PLAYERS):
  board[random.randint(0, BOARD_SIZE - 1)] = LADDER_SQUARE
  board[random.randint(0, BOARD_SIZE - 1)] = SNAKE_SQUARE

# Set the last square to be the end square
board[BOARD_SIZE - 1] = END_SQUARE

# List of players, with their current position on the board
players = []
for i in range(NUM_PLAYERS):
  players.append(START_SQUARE)

# Main game loop
game_over = False
current_player = 0
while not game_over:
  # Roll the dice and move the player
  dice_roll = random.randint(1, 6)
  players[current_player] += dice_roll
  square = board[players[current_player]]

  # Check if the player landed on a ladder or snake
  if square == LADDER_SQUARE:
    players[current_player] += dice_roll
  elif square == SNAKE_SQUARE:
    players[current_player] -= dice_roll

  # Check if the player has reached the end square
  if square == END_SQUARE:
    game_over = True

  # Switch to the other player
  current_player = (current_player + 1) % NUM_PLAYERS

# Print the winner
print("Player " + str(current_player + 1) + " wins!")
